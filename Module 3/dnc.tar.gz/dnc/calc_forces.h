void calc_forces(Node *particles,int N, float eps);
